package com.Myapps.airBnbApp.entity.Enums;

public enum Roles {
 Guest,
 Manager
}
