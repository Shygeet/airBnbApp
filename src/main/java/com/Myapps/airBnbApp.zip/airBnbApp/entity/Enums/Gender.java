package com.Myapps.airBnbApp.entity.Enums;

public enum Gender {
Male,
Female
}
