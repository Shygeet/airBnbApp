package com.Myapps.airBnbApp.entity.Enums;

public enum PaymentStatus {
Sucess,
Pending,
Cancelled
}
